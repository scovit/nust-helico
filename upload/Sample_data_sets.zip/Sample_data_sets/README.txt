
These sample input data sets can be downloaded on your computer and then uploaded on the web server following the "Upload a data set" link in the "Home" 
page. The lists will be loaded as "Personal data sets" in the "Explore" page and all the available analysis in NuST can be tested. Alternatively, the lists 
can be added  ("Add" tab) in the "Explore" page (see menu on top of each page) as new personal data sets, and then analyzed with the different tools.


SAMPLE1: ribosomal genes. This sample data set contains the list of genes annotated as ribosomal subunits or ribosomal RNAs according to Regulon DB 
database 7.2 (Gama-Castro et al Nucleic Acids Res 2011).

SAMPLE2: random list. This sample data set is a collection of 200 randomly chosen genes. Since these genes are randomly chosen no significant cluster is 
expected from the linear aggregation analysis.

SAMPLE3: Ter macrodomain. This sample data set contains all genes located inside the Ter macrodomain (the coordinates of macrodomains can be found in the "Help" page). 
A significant aggregation is therefore expected from the linear aggregation analysis. The clusters positions can be directly compared with the Ter 
macrodomain position in the graphical output of the linear aggregation analysis. 


